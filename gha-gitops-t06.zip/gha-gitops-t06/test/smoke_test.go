package test

// After an apply: is the page up, and does it say what the merged pull request said it would?
// Runs from the GitHub runner over plain HTTP, exactly like a visitor would.

import (
	"os"
	"strings"
	"testing"
	"time"

	http_helper "github.com/gruntwork-io/terratest/modules/http-helper"
)

func TestSmokePageShowsTheMessage(t *testing.T) {
	url, want := os.Getenv("APP_URL"), os.Getenv("EXPECTED_MESSAGE")
	if url == "" || want == "" {
		t.Skip("APP_URL and EXPECTED_MESSAGE are not set; the apply workflow sets them from terraform output")
	}
	// A new VM needs a few minutes for cloud-init to install nginx, so be patient: up to 10 minutes.
	http_helper.HttpGetWithRetryWithCustomValidation(t, url, nil, 40, 15*time.Second, func(status int, body string) bool {
		return status == 200 && strings.Contains(body, want)
	})
}
