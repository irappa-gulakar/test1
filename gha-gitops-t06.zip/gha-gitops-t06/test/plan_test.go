package test

// Policy checks on the pull request's saved plan. They read plan.json only: no Azure credentials,
// no resources created, a few seconds per run. Each test is one rule the team agreed on.

import (
	"os"
	"strconv"
	"strings"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	tfjson "github.com/hashicorp/terraform-json"
	"github.com/stretchr/testify/require"
)

// The size the lab quota is planned around.
const approvedVMSize = "Standard_D2ds_v5"

// The region the subscription has VM quota in.
const approvedLocation = "centralindia"

// Tags every taggable resource must carry, so a stray VM can always be traced to its owner.
var requiredTags = []string{"trainee", "managed_by"}

// Sources that mean "anyone on the internet".
var internetSources = map[string]bool{"*": true, "0.0.0.0/0": true, "::/0": true, "Internet": true, "Any": true}

// loadPlan reads the plan JSON the workflow produced with `terraform show -json tfplan`.
func loadPlan(t *testing.T) *terraform.PlanStruct {
	t.Helper()
	path := os.Getenv("PLAN_JSON")
	if path == "" {
		t.Skip("PLAN_JSON is not set; run: terraform show -json tfplan > plan.json && PLAN_JSON=$PWD/plan.json go test")
	}
	raw, err := os.ReadFile(path)
	require.NoError(t, err, "reading %s", path)
	plan, err := terraform.ParsePlanJSON(string(raw))
	require.NoError(t, err, "parsing %s", path)
	return plan
}

// managed returns the resources Terraform will manage after this plan (data sources left out).
func managed(plan *terraform.PlanStruct) []*tfjson.StateResource {
	var out []*tfjson.StateResource
	for _, r := range plan.ResourcePlannedValuesMap {
		if r.Mode == tfjson.ManagedResourceMode {
			out = append(out, r)
		}
	}
	return out
}

// ofType filters managed resources by Terraform type.
func ofType(plan *terraform.PlanStruct, typ string) []*tfjson.StateResource {
	var out []*tfjson.StateResource
	for _, r := range managed(plan) {
		if r.Type == typ {
			out = append(out, r)
		}
	}
	return out
}

// stringsOf collects a string attribute and a list attribute into one slice (Azure NSG rules have both forms).
func stringsOf(r *tfjson.StateResource, single, list string) []string {
	var out []string
	if s, ok := r.AttributeValues[single].(string); ok && s != "" {
		out = append(out, s)
	}
	if l, ok := r.AttributeValues[list].([]interface{}); ok {
		for _, v := range l {
			if s, ok := v.(string); ok {
				out = append(out, s)
			}
		}
	}
	return out
}

// coversPort reports whether an NSG port expression ("22", "*", "20-30") includes port.
func coversPort(expr string, port int) bool {
	if expr == "*" {
		return true
	}
	lo, hi, isRange := strings.Cut(expr, "-")
	if !isRange {
		hi = lo
	}
	a, errA := strconv.Atoi(strings.TrimSpace(lo))
	b, errB := strconv.Atoi(strings.TrimSpace(hi))
	return errA == nil && errB == nil && a <= port && port <= b
}

// Exactly one VM, and it's the size the quota was planned for.
func TestPlanVMIsTheApprovedSize(t *testing.T) {
	t.Parallel()
	vms := ofType(loadPlan(t), "azurerm_linux_virtual_machine")
	require.Len(t, vms, 1, "the lab has exactly one VM")
	require.Equal(t, approvedVMSize, vms[0].AttributeValues["size"], "VM size")
}

// Keys only: a password is one more thing to guess.
func TestPlanPasswordSignInIsOff(t *testing.T) {
	t.Parallel()
	for _, vm := range ofType(loadPlan(t), "azurerm_linux_virtual_machine") {
		require.Equal(t, true, vm.AttributeValues["disable_password_authentication"], "%s allows passwords", vm.Address)
	}
}

// SSH open to the whole internet is the classic way to meet a botnet.
func TestPlanSSHIsNeverOpenToTheInternet(t *testing.T) {
	t.Parallel()
	for _, rule := range ofType(loadPlan(t), "azurerm_network_security_rule") {
		v := rule.AttributeValues
		if v["direction"] != "Inbound" || v["access"] != "Allow" {
			continue
		}
		reachesSSH := false
		for _, p := range stringsOf(rule, "destination_port_range", "destination_port_ranges") {
			reachesSSH = reachesSSH || coversPort(p, 22)
		}
		if !reachesSSH {
			continue
		}
		for _, src := range stringsOf(rule, "source_address_prefix", "source_address_prefixes") {
			require.False(t, internetSources[src], "%s opens SSH to %q; list your own IP in allowed_ssh_cidrs instead", rule.Address, src)
		}
	}
}

// Every taggable resource says whose it is.
func TestPlanEverythingIsTagged(t *testing.T) {
	t.Parallel()
	for _, r := range managed(loadPlan(t)) {
		tags, taggable := r.AttributeValues["tags"]
		if !taggable {
			continue
		}
		m, _ := tags.(map[string]interface{})
		for _, k := range requiredTags {
			require.Contains(t, m, k, "%s is missing tag %q", r.Address, k)
		}
	}
}

// Everything lands in the one region with quota.
func TestPlanStaysInTheApprovedRegion(t *testing.T) {
	t.Parallel()
	for _, r := range managed(loadPlan(t)) {
		if loc, ok := r.AttributeValues["location"].(string); ok {
			require.Equal(t, approvedLocation, loc, "%s location", r.Address)
		}
	}
}
