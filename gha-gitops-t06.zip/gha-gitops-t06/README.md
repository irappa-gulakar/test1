# GitOps Lab: Terraform on Azure, Driven by Pull Requests

This repo is your lab. Everything in Azure comes from what's in `main`, and `main` changes only through pull requests. You never run Terraform yourself: GitHub Actions does it for you, using an Azure identity that trusts this repo, with no passwords or keys anywhere.

## What you're building

One Ubuntu VM in a subnet of a virtual network, with a public IP. nginx serves a page showing the `message` from `infra/terraform.tfvars`. The network security group lets in HTTP only. SSH stays closed unless you list your own IP.

## How a change travels

1. You edit a file on a branch and open a pull request into `main`.
2. **Terraform plan** runs six checks: format and validate, tfsec, Checkov, Trivy, a plan (posted as a comment on your PR) and Terratest rules on that plan. It uses a read-only Azure identity.
3. When all six pass, you can merge. Nothing can reach `main` any other way.
4. **Terraform apply** runs on `main` in the `production` environment, with the only identity allowed to build. It plans again, applies that plan, then a Terratest smoke test opens your page to check that it shows your message.

Your step-by-step guide: [Trainee steps](https://github.com/caelus-engineering-labs/azure-terraform-policy-gitops-gha/blob/main/docs/quickstart.md#your-steps). In short: edit `infra/terraform.tfvars` in a pull request, read the plan comment, merge, and open the URL in the **Terraform apply** run's summary.

## Files

| Path | What it is |
|---|---|
| `infra/terraform.tfvars` | **Your settings: the file you change.** |
| `infra/*.tf` | The VM, network and security rules |
| `infra/templates/cloud-init.yaml.tftpl` | What the VM does on first boot (installs nginx, writes the page) |
| `test/plan_test.go` | Terratest rules every plan must pass |
| `test/smoke_test.go` | Terratest check that the deployed page is up |
| `.github/workflows/terraform-pr.yml` | The pull request pipeline |
| `.github/workflows/terraform-apply.yml` | The merge pipeline |
| `.github/workflows/terraform-destroy.yml` | Manual clean-up |
