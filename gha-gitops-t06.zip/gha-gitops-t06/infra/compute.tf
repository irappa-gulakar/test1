# The VM's network card, plugged into the subnet and wearing the public IP (on purpose: Trivy and Checkov are told why).
#trivy:ignore:AVD-AZU-0076
resource "azurerm_network_interface" "web" {
  #checkov:skip=CKV_AZURE_119:A public IP on this NIC is the lab's whole architecture; the NSG admits only HTTP.
  name                = "nic-${local.name}"
  location            = var.location
  resource_group_name = data.azurerm_resource_group.lab.name
  tags                = local.tags

  # One private address from the subnet, plus the public one in front of it.
  ip_configuration {
    name                          = "primary"
    subnet_id                     = azurerm_subnet.web.id
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.web.id
  }
}

# Belt and braces: the same bouncer at the NIC as at the subnet, so moving the NIC can't sneak past it.
resource "azurerm_network_interface_security_group_association" "web" {
  network_interface_id      = azurerm_network_interface.web.id
  network_security_group_id = azurerm_network_security_group.web.id
}

# The star of the show: Ubuntu with nginx, saying whatever var.message says.
# Changing the message changes custom_data, which rebuilds the VM: watch the plan say so.
resource "azurerm_linux_virtual_machine" "web" {
  name                            = "vm-${local.name}"
  computer_name                   = "web-${var.trainee}"
  location                        = var.location
  resource_group_name             = data.azurerm_resource_group.lab.name
  size                            = var.vm_size
  admin_username                  = "azureuser"
  disable_password_authentication = true
  allow_extension_operations      = false
  secure_boot_enabled             = true
  vtpm_enabled                    = true
  network_interface_ids           = [azurerm_network_interface.web.id]
  custom_data = base64encode(templatefile("${path.module}/templates/cloud-init.yaml.tftpl", {
    message = var.message
    trainee = var.trainee
  }))
  tags = local.tags

  # One block per key; any of them can sign in, none of them is a password.
  dynamic "admin_ssh_key" {
    for_each = var.admin_ssh_public_keys
    content {
      username   = "azureuser"
      public_key = admin_ssh_key.value
    }
  }

  # A modest SSD; the page is small.
  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "StandardSSD_LRS"
  }

  # Ubuntu 24.04 LTS, Gen2, so Trusted Launch (secure boot + vTPM) works.
  source_image_reference {
    publisher = "Canonical"
    offer     = "ubuntu-24_04-lts"
    sku       = "server"
    version   = "latest"
  }

  # Serial console and screenshots in the portal, stored by Azure: handy when cloud-init sulks.
  boot_diagnostics {}
}
