# Credentials come from the environment (ARM_CLIENT_ID, ARM_TENANT_ID, ARM_SUBSCRIPTION_ID, ARM_USE_OIDC):
# nothing to leak because there's nothing here.
provider "azurerm" {
  features {}

  # The pipeline identities can't register resource providers, and shouldn't need to.
  resource_provider_registrations = "none"
}
