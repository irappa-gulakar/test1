# The resource group is made by the trainer's setup script and only borrowed here: the pipeline
# may build inside it but has no right to create, rename or delete it.
data "azurerm_resource_group" "lab" {
  name = "rg-gha-${var.trainee}"


}
