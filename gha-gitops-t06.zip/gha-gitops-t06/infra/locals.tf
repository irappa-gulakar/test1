# One naming scheme and one set of tags, so nobody has to guess whose VM is whose.
locals {
  name = "gha-${var.trainee}"

  tags = {
    trainee    = var.trainee
    session    = "gha"
    managed_by = "terraform"
    deployed   = "github-actions"
  }
}
