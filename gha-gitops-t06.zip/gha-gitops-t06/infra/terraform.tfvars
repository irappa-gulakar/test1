# Your lab's settings. Change one, open a pull request, and the pipeline shows you what it would do.
trainee = "t06"
message = "Hello from t06"

# Keys allowed to sign in to the VM as azureuser. Add your own public key if you like.
admin_ssh_public_keys = [
  "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBvdQj2agkd7HwvmK/MdnhaiTBk+SSifC76qx6h8jeNE vivekanandpv@MacBookPro.local",
]

# Who may reach SSH. Empty = nobody. Add "<your-ip>/32" to open it for yourself; never "0.0.0.0/0".
allowed_ssh_cidrs = []
