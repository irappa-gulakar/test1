# Where to point your browser.
output "url" {
  description = "The web page."
  value       = "http://${azurerm_public_ip.web.ip_address}"
}

# The message the page should be showing; the smoke test checks for it.
output "message" {
  description = "The text the page should show."
  value       = var.message
}

# For the curious: the VM's name in the portal.
output "vm_name" {
  description = "Name of the VM."
  value       = azurerm_linux_virtual_machine.web.name
}
