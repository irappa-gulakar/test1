# The rules of engagement: which Terraform, which provider, and where the memory (state) lives.
terraform {
  required_version = ">= 1.10.0"

  # Pinned to a minor line: patch fixes welcome, surprise rewrites not.
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 5.8"
    }
  }

  # Remote state in Azure Storage, reached with the pipeline's OIDC token. The account and
  # container are passed in by the workflow (-backend-config), so this file holds no addresses.
  backend "azurerm" {
    key              = "gitops/terraform.tfstate"
    use_oidc         = true
    use_azuread_auth = true
  }
}
