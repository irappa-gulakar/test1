# Who this lab belongs to. Set once by the trainer's setup script; everything else is named after it.
variable "trainee" {
  description = "Trainee ID (t01..t99) or \"trainer\"."
  type        = string

  validation {
    condition     = can(regex("^(t[0-9]{2}|trainer)$", var.trainee))
    error_message = "trainee must look like t07, or be \"trainer\"."
  }
}

# Central India: where the subscription actually has VM quota.
variable "location" {
  description = "Azure region for every resource."
  type        = string
  default     = "centralindia"
}

# Two vCPUs is plenty for a page that says hello.
variable "vm_size" {
  description = "VM size. The lab quota is sized for Standard_D2ds_v5."
  type        = string
  default     = "Standard_D2ds_v5"
}

# The line you change in your pull requests. Kept to plain characters so it can't break the web page.
variable "message" {
  description = "Text shown on the web page."
  type        = string
  default     = "Hello from GitOps"

  validation {
    condition     = can(regex("^[A-Za-z0-9 .,!?'-]{1,80}$", var.message))
    error_message = "message: 1 to 80 characters, using letters, digits, spaces and . , ! ? ' - only."
  }
}

# Keys that may sign in as azureuser. Passwords are switched off entirely.
variable "admin_ssh_public_keys" {
  description = "SSH public keys allowed to sign in to the VM."
  type        = list(string)

  validation {
    condition     = length(var.admin_ssh_public_keys) > 0
    error_message = "Provide at least one SSH public key."
  }
}

# Empty means no SSH from anywhere. Terratest fails the pull request if this is ever opened to the whole internet.
variable "allowed_ssh_cidrs" {
  description = "Source CIDRs allowed to reach SSH (port 22). Leave empty to keep SSH closed."
  type        = list(string)
  default     = []
}
