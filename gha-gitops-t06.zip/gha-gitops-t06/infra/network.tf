# A small private neighbourhood for one VM.
resource "azurerm_virtual_network" "lab" {
  name                = "vnet-${local.name}"
  location            = var.location
  resource_group_name = data.azurerm_resource_group.lab.name
  address_space       = ["10.20.0.0/16"]
  tags                = local.tags
}

# One street in the neighbourhood, where the web VM lives.
resource "azurerm_subnet" "web" {
  name                 = "snet-web"
  resource_group_name  = data.azurerm_resource_group.lab.name
  virtual_network_name = azurerm_virtual_network.lab.name
  address_prefixes     = ["10.20.1.0/24"]
}

# The bouncer at the subnet's door.
resource "azurerm_network_security_group" "web" {
  name                = "nsg-${local.name}"
  location            = var.location
  resource_group_name = data.azurerm_resource_group.lab.name
  tags                = local.tags
}

# The whole point of the lab is a page anyone can open, so HTTP is public on purpose (Checkov is told why).
resource "azurerm_network_security_rule" "http" {
  #checkov:skip=CKV_AZURE_160:Public HTTP is the demo; the page serves a static greeting and nothing else.
  name                        = "allow-http-from-internet"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "80"
  source_address_prefix       = "Internet"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.lab.name
  network_security_group_name = azurerm_network_security_group.web.name
}

# SSH only from the addresses you list; with none listed, this rule doesn't exist at all.
resource "azurerm_network_security_rule" "ssh" {
  count = length(var.allowed_ssh_cidrs) > 0 ? 1 : 0

  name                        = "allow-ssh-from-listed-cidrs"
  priority                    = 110
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "22"
  source_address_prefixes     = var.allowed_ssh_cidrs
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.lab.name
  network_security_group_name = azurerm_network_security_group.web.name
}

# Hang the bouncer on the door.
resource "azurerm_subnet_network_security_group_association" "web" {
  subnet_id                 = azurerm_subnet.web.id
  network_security_group_id = azurerm_network_security_group.web.id
}

# A fixed public address, so the URL survives the VM being rebuilt.
resource "azurerm_public_ip" "web" {
  name                = "pip-${local.name}"
  location            = var.location
  resource_group_name = data.azurerm_resource_group.lab.name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = local.tags
}
